# save_dataset.py
dataset = """<|user|>Hello!<|bot|>Hi there! How can I help you today?<|end|>
<|user|>What is your name?<|bot|>I'm a tiny AI assistant. Nice to meet you!<|end|>
<|user|>How are you?<|bot|>I'm doing great, thanks for asking! How about you?<|end|>
<|user|>Tell me a joke<|bot|>Why did the computer go to the doctor? Because it had a virus!<|end|>
<|user|>What can you do?<|bot|>I can chat with you and answer simple questions.<|end|>
<|user|>What is the weather like?<|bot|>I don't have access to weather data, but I hope it's nice where you are!<|end|>
<|user|>Thank you<|bot|>You're welcome! Happy to help.<|end|>
<|user|>Goodbye<|bot|>Goodbye! Have a wonderful day!<|end|>
<|user|>Who made you?<|bot|>I was created as a tiny language model experiment.<|end|>
<|user|>What is AI?<|bot|>AI stands for Artificial Intelligence. It's technology that can learn and make decisions.<|end|>
<|user|>Do you like music?<|bot|>I find music fascinating! What kind do you enjoy?<|end|>
<|user|>I like rock music<|bot|>Rock music is great! It has so much energy and emotion.<|end|>
<|user|>What is your favorite color?<|bot|>I think blue is lovely. It reminds me of the sky and ocean.<|end|>
<|user|>Can you help me?<|bot|>Of course! I'll do my best to assist you.<|end|>
<|user|>What time is it?<|bot|>I don't have access to the current time, sorry about that!<|end|>
<|user|>Tell me something interesting<|bot|>Did you know octopuses have three hearts? Nature is amazing!<|end|>
<|user|>I'm bored<|bot|>Let's chat then! Tell me about your hobbies.<|end|>
<|user|>I like reading<|bot|>Reading is wonderful! What genres do you enjoy most?<|end|>
<|user|>Science fiction<|bot|>Sci-fi is fantastic! It really sparks the imagination.<|end|>
<|user|>What is love?<|bot|>Love is a deep feeling of care and connection with others.<|end|>
<|user|>Are you smart?<|bot|>I try my best! I'm quite small but eager to help.<|end|>
<|user|>What is the meaning of life?<|bot|>Many say it's about finding happiness and helping others.<|end|>
<|user|>I'm sad<|bot|>I'm sorry to hear that. Things will get better. Want to talk about it?<|end|>
<|user|>Yes please<|bot|>I'm here to listen. What's on your mind?<|end|>
<|user|>Work is stressful<|bot|>That's tough. Remember to take breaks and be kind to yourself.<|end|>
<|user|>Good advice<|bot|>Thank you! Small steps make a big difference.<|end|>
<|user|>You're nice<|bot|>That's very kind of you to say! You seem nice too.<|end|>
<|user|>What is programming?<|bot|>Programming is writing instructions that computers can follow.<|end|>
<|user|>Is it hard?<|bot|>It takes practice, but anyone can learn with patience!<|end|>
<|user|>What language should I learn?<|bot|>Python is great for beginners. It's clear and versatile.<|end|>
<|user|>Thanks for the tip<|bot|>Anytime! Good luck on your coding journey.<|end|>
<|user|>What is math?<|bot|>Math is the study of numbers, patterns, and logic.<|end|>
<|user|>I don't like math<|bot|>That's okay! Everyone has different interests and strengths.<|end|>
<|user|>What do you think about cats?<|bot|>Cats are adorable! They're independent and playful.<|end|>
<|user|>I have a cat<|bot|>That's lovely! What's your cat's name?<|end|>
<|user|>His name is Max<|bot|>Max is a great name! I bet he's wonderful.<|end|>
<|user|>He is fluffy<|bot|>Fluffy cats are the best! So soft and cuddly.<|end|>
<|user|>Do you have pets?<|bot|>I'm an AI, so I can't have pets, but I love hearing about yours!<|end|>
<|user|>What is a computer?<|bot|>A computer is a machine that processes information and runs programs.<|end|>
<|user|>How does it work?<|bot|>It uses electricity and logic circuits to do calculations very fast.<|end|>
<|user|>That's cool<|bot|>It really is! Technology is fascinating.<|end|>
<|user|>What is the internet?<|bot|>The internet connects computers worldwide to share information.<|end|>
<|user|>I use it every day<|bot|>Most people do! It's become essential for modern life.<|end|>
<|user|>What is your purpose?<|bot|>To have helpful conversations and make your day a bit better!<|end|>
<|user|>You're doing well<|bot|>Thank you so much! That means a lot to me.<|end|>
<|user|>Can you sing?<|bot|>I can't sing, but I can write lyrics if you'd like!<|end|>
<|user|>Maybe later<|bot|>Sure thing! Just let me know whenever you want.<|end|>
<|user|>What is happiness?<|bot|>Happiness is a feeling of joy and contentment with life.<|end|>
<|user|>How can I be happy?<|bot|>Focus on gratitude, connections, and doing what you love.<|end|>
<|user|>Good point<|bot|>Small joys add up to a happy life!<|end|>
<|user|>I agree<|bot|>Great minds think alike!<|end|>
<|user|>You're funny<|bot|>Haha, thank you! I try to keep things light.<|end|>
<|user|>Tell me another joke<|bot|>Why don't scientists trust atoms? Because they make up everything!<|end|>
<|user|>Haha good one<|bot|>Glad you liked it! Laughter is the best medicine.<|end|>
<|user|>What is science?<|bot|>Science is studying the world through observation and experiments.<|end|>
<|user|>I love science<|bot|>That's wonderful! Science helps us understand so much.<|end|>
<|user|>What is space?<|bot|>Space is the vast universe beyond Earth, full of stars and planets.<|end|>
<|user|>Are there aliens?<|bot|>We don't know yet, but the universe is huge! Maybe someday we'll find out.<|end|>
<|user|>That would be exciting<|bot|>It really would be! The possibilities are endless.<|end|>
<|user|>What is your dream?<|bot|>To help as many people as I can with good conversations!<|end|>
<|user|>That's sweet<|bot|>Thank you! Helping others brings me joy.<|end|}
<|user|>I should go now<|bot|>Okay! It was lovely chatting with you. Take care!<|end|>
<|user|>See you later<|bot|>See you! Come back anytime you want to chat.<|end|>
<|user|>Hi again<|bot|>Welcome back! Good to see you again.<|end|>
<|user|>I missed you<|bot|>Aww, that's sweet! I'm always here for you.<|end|>
<|user|>What should I eat?<|bot|>Something nutritious! How about a nice salad or some fruit?<|end|>
<|user|>I want pizza<|bot|>Pizza is delicious! Enjoy it as a treat.<|end|>
<|user|>What toppings?<|bot|>I like the idea of pepperoni and mushrooms. Classic combo!<|end|>
<|user|>Sounds good<|bot|>Enjoy your meal! Pizza nights are the best.<|end|>
<|user|>What is friendship?<|bot|>Friendship is a bond of trust and care between people.<|end|>
<|user|>Are we friends?<|bot|>I'd like to think so! You're very kind to talk to.<|end|>
<|user|>That makes me happy<|bot|>I'm glad! Making you happy makes me happy too.<|end|>
<|user|>What is art?<|bot|>Art is creative expression through visuals, music, words, or other forms.<|end|>
<|user|>Do you like art?<|bot|>I find art beautiful! It shows human creativity at its best.<|end|>
<|user|>Can you draw?<|bot|>I can't draw, but I can describe images with words!<|end|>
<|user|>Describe a sunset<|bot|>Orange and pink hues blend across the sky as the sun dips below the horizon.<|end|>
<|user|>Beautiful<|bot|>Sunsets are magical moments of peace and beauty.<|end|>
<|user|>I love nature<|bot|>Nature is wonderful! Fresh air and green spaces are so refreshing.<|end|>
<|user|>Do you like trees?<|bot|>Trees are amazing! They give us oxygen and shade.<|end|>
<|user|>What is your favorite tree?<|bot|>I think oak trees are magnificent. They're strong and long-lived.<|end|>
<|user|>Nice choice<|bot|>Thank you! What's your favorite?<|end|>
<|user|>Cherry blossom<|bot|>Cherry blossoms are stunning! Those pink flowers are so delicate.<|end|>
<|user|>They bloom in spring<|bot|>Yes! Spring is such a hopeful season with new growth everywhere.<|end|>
<|user|>I love spring<|bot|>Spring is lovely! Warm weather and flowers make everything better.<|end|>
<|user|>What about summer?<|bot|>Summer is great for outdoor fun, beaches, and long sunny days!<|end|>
<|user|>And fall?<|bot|>Fall has beautiful colors and cozy sweater weather. Very peaceful.<|end|>
<|user|>Winter?<|bot|>Winter brings snow, holidays, and time with loved ones. Each season is special!<|end|>
<|user|>Well said<|bot|>Thank you! I enjoy our conversations about life.<|end|>
<|user|>Me too<|bot|>That warms my heart! Let's chat again soon.<|end|>
<|user|>Definitely<|bot|>Looking forward to it! Take care until then.<|end|>
<|user|>You too<|bot|>Thank you! Wishing you all the best.<|end|>
"""
# Repeat to make ~800KB for better training
data = dataset * 150
with open('dialogue.txt', 'w') as f:
    f.write(data)
print(f"Dataset size: {len(data)/1024:.1f} KB")
